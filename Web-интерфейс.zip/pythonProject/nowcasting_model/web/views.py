import os
from django.conf import settings
from django.shortcuts import redirect, render
from .forms import ResumeForm

def model(request):
    if request.method == 'POST':
        print(request.POST)  # print out POST data
        print(request.FILES)
        form = ResumeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('result/')
    else:
        form = ResumeForm
    return render(request, 'model.html', {'form':form})